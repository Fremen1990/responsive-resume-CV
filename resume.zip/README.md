# Tomasz Stanisz Resume

<img src="TomaszStanisz-Resume.png"/>
